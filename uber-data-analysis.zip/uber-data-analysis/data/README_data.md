# Dataset Download Instructions

## Source
Download from Kaggle: https://www.kaggle.com/datasets/fivethirtyeight/uber-pickups-in-new-york-city

## Files Required
Place the following CSV files inside this `data/` folder:

- `uber-raw-data-apr14.csv`
- `uber-raw-data-may14.csv`
- `uber-raw-data-jun14.csv`
- `uber-raw-data-jul14.csv`
- `uber-raw-data-aug14.csv`
- `uber-raw-data-sep14.csv`

## Column Description

| Column      | Type     | Description                          |
|-------------|----------|--------------------------------------|
| Date/Time   | datetime | Pickup timestamp                     |
| Lat         | float    | Latitude of pickup location          |
| Lon         | float    | Longitude of pickup location         |
| Base        | string   | Uber dispatch base code (B02512 etc) |

## Dataset Size
- Total Records: ~3,457,286 rows
- Date Range: April 2014 – September 2014
- City: New York City, USA

## Note
The CSV files are NOT included in this repository due to their large size.
Download directly from Kaggle using the link above.
You may need a free Kaggle account to download.
