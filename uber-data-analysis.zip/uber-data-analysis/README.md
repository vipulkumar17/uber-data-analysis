# 🚗 Uber Data Analysis — EDA Project

> **B.Tech CSE (Data Science) | 3rd Year Project**  
> Exploratory Data Analysis on 3.4M+ Uber ride records from New York City (2014)

---

## 📌 Project Overview

This project performs an in-depth **Exploratory Data Analysis (EDA)** on Uber's raw pickup data from New York City. Using Python's data science stack, we uncover hidden patterns in ride demand, surge pricing hotspots, peak hours, and geographic distribution.

---

## 📁 Project Structure

```
uber-data-analysis/
│
├── data/
│   └── README_data.md          # Instructions to download dataset
│
├── notebooks/
│   └── uber_eda.ipynb          # Main Jupyter Notebook (full analysis)
│
├── scripts/
│   ├── load_data.py            # Data loading & merging
│   ├── feature_engineering.py  # DateTime feature extraction
│   ├── eda_analysis.py         # EDA functions
│   └── visualizations.py       # All plot functions
│
├── visualizations/
│   └── (auto-saved plots)      # PNG charts saved here
│
├── outputs/
│   └── insights_summary.txt    # Key findings & business insights
│
├── requirements.txt            # Python dependencies
└── README.md                   # This file
```

---

## 📊 Dataset

- **Source:** [Kaggle — Uber Pickups in New York City](https://www.kaggle.com/datasets/fivethirtyeight/uber-pickups-in-new-york-city)
- **Size:** ~3.4 Million records (April–September 2014)
- **Columns:** `Date/Time`, `Lat`, `Lon`, `Base`

> Download the dataset from Kaggle and place the CSV files inside the `data/` folder.

---

## 🔧 Tech Stack

| Tool | Purpose |
|------|---------|
| Python 3.10+ | Core language |
| Pandas | Data loading, wrangling, groupby |
| NumPy | Numerical operations |
| Matplotlib | Base plotting |
| Seaborn | Statistical visualizations |
| Plotly | Interactive charts |
| Folium | Geospatial mapping |
| Jupyter Notebook | Development environment |

---

## 🚀 How to Run

### 1. Clone the repository
```bash
git clone https://github.com/your-username/uber-data-analysis.git
cd uber-data-analysis
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Download dataset
Follow instructions in `data/README_data.md` to download and place CSV files.

### 4. Run the notebook
```bash
jupyter notebook notebooks/uber_eda.ipynb
```

Or run individual scripts:
```bash
python scripts/eda_analysis.py
```

---

## 📈 Key Findings

1. **Evening Rush Peak** — 5–7 PM accounts for 23% of all daily rides
2. **Weekend Surge** — Friday & Saturday nights see 2.4× average hourly demand
3. **Manhattan Dominates** — 68% of all pickups occur in Manhattan
4. **Monthly Growth** — Rides grew 41% from April to September 2014
5. **Surge Pricing** — 18.4% of rides occur during surge pricing windows

---

## 📷 Sample Visualizations

| Chart | Description |
|-------|-------------|
| Hourly Demand Bar Chart | Ride frequency by hour of day |
| Weekday Heatmap | Demand intensity (Hour × Day) |
| Geo Scatter Plot | NYC pickup hotspot map |
| Monthly Trend Line | Ride growth over 6 months |
| Base Comparison | Market share by dispatch base |

---

## 💡 Business Recommendations

- **Fleet Optimization:** Deploy 30% more drivers in Manhattan 5–8 PM weekdays
- **Surge Alerts:** Predictive surge notifications for Fri/Sat nights (+18% revenue)
- **Airport Corridors:** Dedicated queuing at JFK & LaGuardia
- **Demand Forecasting:** Use time features (hour, weekday, month) for ML prediction

---

## 👤 Author

**Vipul Kumar**  
B.Tech CSE (Data Science), 3rd Year  
ABES Engineering College, Ghaziabad  
📧 kumarvipul6392@gmail.com  
🔗 [LinkedIn](https://linkedin.com) | [GitHub](https://github.com)

---

## 📄 License

This project is open source and available under the [MIT License](LICENSE).
