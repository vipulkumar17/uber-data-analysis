"""
feature_engineering.py
=======================
Extracts DateTime-based features from the raw Uber dataset.
These features are used for all temporal analysis.

Author: Vipul Kumar
Project: Uber Data Analysis — B.Tech 3rd Year
"""

import pandas as pd


def parse_datetime(df, col="Date/Time", fmt="%m/%d/%Y %H:%M:%S"):
    """
    Parse the Date/Time column to datetime type.

    Parameters:
        df  (pd.DataFrame): Raw Uber DataFrame.
        col (str)         : Column name containing datetime strings.
        fmt (str)         : Expected datetime format.

    Returns:
        pd.DataFrame: DataFrame with parsed datetime column.
    """
    df = df.copy()
    df[col] = pd.to_datetime(df[col], format=fmt)
    print(f"Parsed '{col}' as datetime. Range: {df[col].min()} → {df[col].max()}")
    return df


def extract_time_features(df, col="Date/Time"):
    """
    Extract hour, day, month, weekday, week number from datetime column.

    Parameters:
        df  (pd.DataFrame): DataFrame with parsed datetime.
        col (str)         : Datetime column name.

    Returns:
        pd.DataFrame: DataFrame with new time-based feature columns.
    """
    df = df.copy()

    df["hour"]    = df[col].dt.hour
    df["day"]     = df[col].dt.day
    df["month"]   = df[col].dt.month
    df["weekday"] = df[col].dt.day_name()          # e.g. 'Monday'
    df["week"]    = df[col].dt.isocalendar().week.astype(int)
    df["date"]    = df[col].dt.date                # just the date part
    df["is_weekend"] = df["weekday"].isin(["Saturday", "Sunday"]).astype(int)

    # Time-of-day buckets
    df["time_of_day"] = pd.cut(
        df["hour"],
        bins=[-1, 5, 11, 16, 20, 23],
        labels=["Late Night", "Morning", "Afternoon", "Evening", "Night"]
    )

    print("New features added:")
    print("  hour, day, month, weekday, week, date, is_weekend, time_of_day")
    return df


def month_name(df, col="month"):
    """
    Map month numbers to month names.

    Parameters:
        df  (pd.DataFrame): DataFrame.
        col (str)         : Month column.

    Returns:
        pd.DataFrame: DataFrame with 'month_name' column.
    """
    month_map = {
        4: "April", 5: "May", 6: "June",
        7: "July", 8: "August", 9: "September"
    }
    df = df.copy()
    df["month_name"] = df[col].map(month_map)
    return df


def run_feature_engineering(df):
    """
    Full pipeline: parse datetime + extract all features.

    Parameters:
        df (pd.DataFrame): Raw Uber DataFrame.

    Returns:
        pd.DataFrame: Feature-enriched DataFrame.
    """
    df = parse_datetime(df)
    df = extract_time_features(df)
    df = month_name(df)
    print(f"\nFeature engineering complete. Columns: {list(df.columns)}")
    return df


# ─── Run directly ────────────────────────────────────────────────────────────
if __name__ == "__main__":
    from load_data import load_uber_data

    df_raw = load_uber_data(data_folder="data/")
    df = run_feature_engineering(df_raw)
    print(df.head())
    print(df.dtypes)
