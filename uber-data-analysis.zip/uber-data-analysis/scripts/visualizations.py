"""
visualizations.py
=================
All visualization / plotting functions for the Uber EDA project.
Each function generates and saves one plot to the visualizations/ folder.

Author: Vipul Kumar
Project: Uber Data Analysis — B.Tech 3rd Year
"""

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns

# Global style settings
sns.set_style("darkgrid")
sns.set_palette("Blues_r")
plt.rcParams.update({
    "figure.figsize"  : (12, 6),
    "axes.titlesize"  : 15,
    "axes.labelsize"  : 12,
    "xtick.labelsize" : 10,
    "ytick.labelsize" : 10,
    "figure.dpi"      : 120,
})

SAVE_DIR = "visualizations/"
os.makedirs(SAVE_DIR, exist_ok=True)


def _save(fig, filename):
    """Save figure to visualizations/ folder."""
    path = os.path.join(SAVE_DIR, filename)
    fig.savefig(path, bbox_inches="tight")
    print(f"  Saved → {path}")
    plt.show()
    plt.close(fig)


# ─── 1. Rides by Hour ────────────────────────────────────────────────────────

def plot_rides_by_hour(df):
    """Bar chart of ride count per hour of day."""
    hourly = df.groupby("hour")["Base"].count()

    fig, ax = plt.subplots()
    bars = ax.bar(
        hourly.index, hourly.values,
        color=["#e63946" if h in [17, 18, 19] else "#457b9d" for h in hourly.index],
        edgecolor="white", linewidth=0.5
    )
    ax.set_title("Uber Rides by Hour of Day", fontweight="bold")
    ax.set_xlabel("Hour of Day (0 = Midnight)")
    ax.set_ylabel("Number of Rides")
    ax.set_xticks(range(24))
    ax.set_xticklabels([f"{h}:00" for h in range(24)], rotation=45, ha="right")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{int(x):,}"))

    # Annotate peak
    peak_hour = hourly.idxmax()
    ax.annotate(
        f"Peak: {peak_hour}:00",
        xy=(peak_hour, hourly[peak_hour]),
        xytext=(peak_hour + 1.5, hourly[peak_hour] * 0.95),
        arrowprops=dict(arrowstyle="->", color="red"),
        color="red", fontsize=10, fontweight="bold"
    )
    fig.tight_layout()
    _save(fig, "01_rides_by_hour.png")


# ─── 2. Rides by Weekday ─────────────────────────────────────────────────────

def plot_rides_by_weekday(df):
    """Bar chart of ride count per day of week."""
    day_order = ["Monday", "Tuesday", "Wednesday",
                 "Thursday", "Friday", "Saturday", "Sunday"]
    daily = df.groupby("weekday")["Base"].count().reindex(day_order)

    fig, ax = plt.subplots()
    colors = ["#e63946" if d in ["Friday", "Saturday"] else "#457b9d" for d in day_order]
    ax.bar(daily.index, daily.values, color=colors, edgecolor="white", linewidth=0.5)
    ax.set_title("Uber Rides by Day of Week", fontweight="bold")
    ax.set_xlabel("Day of Week")
    ax.set_ylabel("Number of Rides")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{int(x):,}"))
    fig.tight_layout()
    _save(fig, "02_rides_by_weekday.png")


# ─── 3. Rides by Month ───────────────────────────────────────────────────────

def plot_rides_by_month(df):
    """Line chart showing ride growth trend month over month."""
    month_order = ["April", "May", "June", "July", "August", "September"]
    monthly = df.groupby("month_name")["Base"].count().reindex(month_order)

    fig, ax = plt.subplots()
    ax.plot(monthly.index, monthly.values, marker="o", color="#457b9d",
            linewidth=2.5, markersize=8, markerfacecolor="#e63946")
    ax.fill_between(monthly.index, monthly.values, alpha=0.15, color="#457b9d")
    ax.set_title("Monthly Ride Growth Trend (Apr–Sep 2014)", fontweight="bold")
    ax.set_xlabel("Month")
    ax.set_ylabel("Total Rides")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{int(x):,}"))
    fig.tight_layout()
    _save(fig, "03_monthly_trend.png")


# ─── 4. Heatmap — Hour × Weekday ─────────────────────────────────────────────

def plot_heatmap(df):
    """Seaborn heatmap: rows = weekday, columns = hour."""
    day_order = ["Monday", "Tuesday", "Wednesday",
                 "Thursday", "Friday", "Saturday", "Sunday"]
    pivot = df.groupby(["weekday", "hour"])["Base"].count().unstack(level=1)
    pivot = pivot.reindex(day_order)

    fig, ax = plt.subplots(figsize=(16, 6))
    sns.heatmap(
        pivot, cmap="YlOrRd",
        linewidths=0.3, linecolor="grey",
        annot=False, ax=ax,
        cbar_kws={"label": "Ride Count"}
    )
    ax.set_title("Heatmap: Ride Demand by Hour and Weekday", fontweight="bold")
    ax.set_xlabel("Hour of Day")
    ax.set_ylabel("Day of Week")
    fig.tight_layout()
    _save(fig, "04_heatmap_hour_weekday.png")


# ─── 5. Rides by Uber Base ───────────────────────────────────────────────────

def plot_base_comparison(df):
    """Pie chart showing market share per Uber dispatch base."""
    base_counts = df.groupby("Base")["Lat"].count().sort_values(ascending=False)

    fig, ax = plt.subplots(figsize=(8, 6))
    colors = ["#1d3557", "#457b9d", "#a8dadc", "#f1faee", "#e63946"]
    wedges, texts, autotexts = ax.pie(
        base_counts.values,
        labels=base_counts.index,
        autopct="%1.1f%%",
        colors=colors,
        startangle=140,
        wedgeprops={"edgecolor": "white", "linewidth": 1.5}
    )
    for at in autotexts:
        at.set_fontsize(9)
    ax.set_title("Ride Distribution by Uber Dispatch Base", fontweight="bold")
    fig.tight_layout()
    _save(fig, "05_base_comparison.png")


# ─── 6. Geo Scatter Plot ─────────────────────────────────────────────────────

def plot_geo_scatter(df, sample_size=80000):
    """
    Scatter plot of pickup lat/lon coordinates (sampled for speed).

    Parameters:
        df          (pd.DataFrame): Feature-engineered DataFrame.
        sample_size (int)         : Number of points to plot.
    """
    sample = df.sample(min(sample_size, len(df)), random_state=42)

    fig, ax = plt.subplots(figsize=(10, 10))
    ax.scatter(
        sample["Lon"], sample["Lat"],
        alpha=0.05, s=1, c="#00b4d8"
    )
    ax.set_xlim(-74.3, -73.7)
    ax.set_ylim(40.50, 40.95)
    ax.set_facecolor("#0d1b2a")
    fig.patch.set_facecolor("#0d1b2a")
    ax.tick_params(colors="white")
    ax.set_title("NYC Uber Pickup Hotspots", fontweight="bold", color="white", fontsize=16)
    ax.set_xlabel("Longitude", color="white")
    ax.set_ylabel("Latitude", color="white")
    for spine in ax.spines.values():
        spine.set_edgecolor("white")
    fig.tight_layout()
    _save(fig, "06_geo_scatter.png")


# ─── 7. Correlation Heatmap ──────────────────────────────────────────────────

def plot_correlation(df):
    """Seaborn correlation heatmap for numeric features."""
    numeric_cols = ["hour", "day", "month", "week", "Lat", "Lon", "is_weekend"]
    corr = df[numeric_cols].corr()

    fig, ax = plt.subplots(figsize=(9, 7))
    mask = np.triu(np.ones_like(corr, dtype=bool))
    sns.heatmap(
        corr, mask=mask, cmap="coolwarm",
        annot=True, fmt=".2f", linewidths=0.5,
        ax=ax, vmin=-1, vmax=1,
        cbar_kws={"shrink": 0.8}
    )
    ax.set_title("Correlation Matrix — Uber Features", fontweight="bold")
    fig.tight_layout()
    _save(fig, "07_correlation_matrix.png")


# ─── 8. Hour × Month Heatmap ─────────────────────────────────────────────────

def plot_hour_month_heatmap(df):
    """Heatmap: hour of day vs month — shows seasonal + daily patterns."""
    pivot = df.groupby(["month_name", "hour"])["Base"].count().unstack(level=1)
    month_order = ["April", "May", "June", "July", "August", "September"]
    pivot = pivot.reindex(month_order)

    fig, ax = plt.subplots(figsize=(16, 5))
    sns.heatmap(pivot, cmap="Blues", linewidths=0.2, ax=ax,
                cbar_kws={"label": "Ride Count"})
    ax.set_title("Heatmap: Ride Demand by Hour and Month", fontweight="bold")
    ax.set_xlabel("Hour of Day")
    ax.set_ylabel("Month")
    fig.tight_layout()
    _save(fig, "08_hour_month_heatmap.png")


# ─── Run All Plots ────────────────────────────────────────────────────────────

def plot_all(df):
    """Generate all visualizations at once."""
    print("\n" + "="*55)
    print("GENERATING ALL VISUALIZATIONS")
    print("="*55)
    plot_rides_by_hour(df)
    plot_rides_by_weekday(df)
    plot_rides_by_month(df)
    plot_heatmap(df)
    plot_base_comparison(df)
    plot_geo_scatter(df)
    plot_correlation(df)
    plot_hour_month_heatmap(df)
    print("\n✅ All plots saved to visualizations/ folder.")


# ─── Run directly ────────────────────────────────────────────────────────────
if __name__ == "__main__":
    from load_data import load_uber_data
    from feature_engineering import run_feature_engineering

    df_raw = load_uber_data("data/")
    df = run_feature_engineering(df_raw)
    plot_all(df)
