"""
load_data.py
============
Loads and merges all Uber CSV files from the data/ folder.
Run this first before any analysis.

Author: Vipul Kumar
Project: Uber Data Analysis — B.Tech 3rd Year
"""

import pandas as pd
import glob
import os


def load_uber_data(data_folder="data/"):
    """
    Load all Uber CSV files from the data folder and merge them.

    Parameters:
        data_folder (str): Path to folder containing CSV files.

    Returns:
        pd.DataFrame: Merged DataFrame with all records.
    """
    # Find all CSV files matching the pattern
    pattern = os.path.join(data_folder, "uber-raw-data-*.csv")
    files = glob.glob(pattern)

    if not files:
        raise FileNotFoundError(
            f"No Uber CSV files found in '{data_folder}'.\n"
            "Please download from Kaggle and place in the data/ folder.\n"
            "See data/README_data.md for instructions."
        )

    print(f"Found {len(files)} file(s):")
    for f in sorted(files):
        print(f"  → {f}")

    # Load and concatenate all files
    dfs = []
    for file in sorted(files):
        df_temp = pd.read_csv(file)
        df_temp["source_file"] = os.path.basename(file)
        dfs.append(df_temp)
        print(f"  Loaded: {os.path.basename(file)} — {len(df_temp):,} rows")

    df = pd.concat(dfs, ignore_index=True)
    print(f"\nTotal records merged: {len(df):,}")
    return df


def basic_info(df):
    """
    Print basic info about the DataFrame.

    Parameters:
        df (pd.DataFrame): The Uber dataset.
    """
    print("\n" + "="*50)
    print("DATASET OVERVIEW")
    print("="*50)
    print(f"Shape         : {df.shape[0]:,} rows × {df.shape[1]} columns")
    print(f"Columns       : {list(df.columns)}")
    print(f"\nData Types:\n{df.dtypes}")
    print(f"\nMissing Values:\n{df.isnull().sum()}")
    print(f"\nFirst 5 rows:\n{df.head()}")


def save_merged(df, output_path="data/uber_merged.csv"):
    """
    Save the merged DataFrame to CSV for quick reloading.

    Parameters:
        df (pd.DataFrame): Merged DataFrame.
        output_path (str): Save path.
    """
    df.to_csv(output_path, index=False)
    print(f"\nMerged dataset saved to: {output_path}")


# ─── Run directly ────────────────────────────────────────────────────────────
if __name__ == "__main__":
    df = load_uber_data(data_folder="data/")
    basic_info(df)
    # Uncomment below to save merged file:
    # save_merged(df)
