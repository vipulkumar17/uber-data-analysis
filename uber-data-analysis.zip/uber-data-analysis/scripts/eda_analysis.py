"""
eda_analysis.py
===============
All Exploratory Data Analysis (EDA) functions.
Each function analyses one aspect of the Uber dataset.

Author: Vipul Kumar
Project: Uber Data Analysis — B.Tech 3rd Year
"""

import pandas as pd
import numpy as np


# ─── 1. Hourly Analysis ──────────────────────────────────────────────────────

def rides_by_hour(df):
    """Count of rides grouped by hour of day."""
    result = df.groupby("hour")["Base"].count().reset_index()
    result.columns = ["hour", "ride_count"]
    print("\n[Hourly Analysis]")
    print(result.to_string(index=False))
    return result


# ─── 2. Daily Analysis ───────────────────────────────────────────────────────

def rides_by_weekday(df):
    """Count of rides grouped by weekday (ordered Mon–Sun)."""
    day_order = ["Monday", "Tuesday", "Wednesday",
                 "Thursday", "Friday", "Saturday", "Sunday"]
    result = df.groupby("weekday")["Base"].count().reindex(day_order).reset_index()
    result.columns = ["weekday", "ride_count"]
    print("\n[Weekday Analysis]")
    print(result.to_string(index=False))
    return result


# ─── 3. Monthly Analysis ─────────────────────────────────────────────────────

def rides_by_month(df):
    """Count of rides grouped by month."""
    month_order = ["April", "May", "June", "July", "August", "September"]
    result = df.groupby("month_name")["Base"].count().reindex(month_order).reset_index()
    result.columns = ["month", "ride_count"]
    print("\n[Monthly Analysis]")
    print(result.to_string(index=False))
    return result


# ─── 4. Base Analysis ────────────────────────────────────────────────────────

def rides_by_base(df):
    """Count of rides grouped by Uber dispatch base."""
    result = df.groupby("Base")["Lat"].count().sort_values(ascending=False).reset_index()
    result.columns = ["base", "ride_count"]
    result["market_share_%"] = (result["ride_count"] / result["ride_count"].sum() * 100).round(2)
    print("\n[Base Analysis]")
    print(result.to_string(index=False))
    return result


# ─── 5. Pivot Heatmap Table ──────────────────────────────────────────────────

def pivot_hour_weekday(df):
    """
    Create a pivot table: rows = weekday, columns = hour.
    Used to generate the demand heatmap.
    """
    day_order = ["Monday", "Tuesday", "Wednesday",
                 "Thursday", "Friday", "Saturday", "Sunday"]
    pivot = df.groupby(["weekday", "hour"])["Base"].count().unstack(level=1)
    pivot = pivot.reindex(day_order)
    print("\n[Heatmap Pivot Table — shape:", pivot.shape, "]")
    print(pivot.head())
    return pivot


# ─── 6. Rush Hour Detection ──────────────────────────────────────────────────

def detect_rush_hours(df, top_n=5):
    """
    Find the top N busiest hours across the dataset.

    Parameters:
        df    (pd.DataFrame): Feature-engineered DataFrame.
        top_n (int)         : Number of top hours to return.

    Returns:
        pd.Series: Top hours by ride count.
    """
    hourly = df.groupby("hour")["Base"].count().sort_values(ascending=False)
    print(f"\n[Top {top_n} Busiest Hours]")
    print(hourly.head(top_n))
    return hourly.head(top_n)


# ─── 7. Weekend vs Weekday ───────────────────────────────────────────────────

def weekend_vs_weekday(df):
    """Compare average ride counts on weekends vs weekdays."""
    result = df.groupby("is_weekend")["Base"].count().reset_index()
    result["type"] = result["is_weekend"].map({0: "Weekday", 1: "Weekend"})
    result.columns = ["is_weekend", "ride_count", "type"]
    print("\n[Weekend vs Weekday]")
    print(result[["type", "ride_count"]].to_string(index=False))
    return result


# ─── 8. Geographic Summary ───────────────────────────────────────────────────

def geo_summary(df):
    """
    Basic geographic bounding box and density summary.
    """
    print("\n[Geographic Summary]")
    print(f"Latitude  range : {df['Lat'].min():.4f} → {df['Lat'].max():.4f}")
    print(f"Longitude range : {df['Lon'].min():.4f} → {df['Lon'].max():.4f}")
    print(f"Center (approx) : ({df['Lat'].mean():.4f}, {df['Lon'].mean():.4f})")

    # NYC bounding box filter
    nyc = df[
        (df["Lat"].between(40.50, 40.95)) &
        (df["Lon"].between(-74.30, -73.65))
    ]
    print(f"Rides within NYC bounds: {len(nyc):,} ({len(nyc)/len(df)*100:.1f}%)")
    return nyc


# ─── 9. Correlation Matrix ───────────────────────────────────────────────────

def correlation_matrix(df):
    """Return correlation matrix for numeric columns."""
    numeric_cols = ["hour", "day", "month", "week", "Lat", "Lon", "is_weekend"]
    corr = df[numeric_cols].corr().round(3)
    print("\n[Correlation Matrix]")
    print(corr)
    return corr


# ─── Run All Analysis ────────────────────────────────────────────────────────

def run_all_eda(df):
    """Run all EDA functions and return results as a dict."""
    print("\n" + "="*55)
    print("RUNNING FULL EDA")
    print("="*55)
    results = {
        "hourly"       : rides_by_hour(df),
        "weekday"      : rides_by_weekday(df),
        "monthly"      : rides_by_month(df),
        "base"         : rides_by_base(df),
        "heatmap"      : pivot_hour_weekday(df),
        "rush_hours"   : detect_rush_hours(df),
        "wknd_vs_wkdy" : weekend_vs_weekday(df),
        "geo"          : geo_summary(df),
        "correlation"  : correlation_matrix(df),
    }
    print("\n✅ EDA complete. All results stored in dict.")
    return results


# ─── Run directly ────────────────────────────────────────────────────────────
if __name__ == "__main__":
    from load_data import load_uber_data
    from feature_engineering import run_feature_engineering

    df_raw = load_uber_data("data/")
    df = run_feature_engineering(df_raw)
    results = run_all_eda(df)
